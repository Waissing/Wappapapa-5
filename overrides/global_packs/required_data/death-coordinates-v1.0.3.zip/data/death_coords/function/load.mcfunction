scoreboard objectives add bizcub.death_coords.tsd custom:time_since_death
scoreboard objectives add bizcub.death_coords.trigger1 trigger

gamerule sendCommandFeedback false
