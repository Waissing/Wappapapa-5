execute as @a if data entity @s LastDeathLocation if score @s bizcub.death_coords.tsd matches 1 run title @s title [{"nbt":"LastDeathLocation.pos[0]","entity":"@s"},", ",{"nbt":"LastDeathLocation.pos[1]","entity":"@s"},", ",{"nbt":"LastDeathLocation.pos[2]","entity":"@s"}]

scoreboard players enable @a bizcub.death_coords.trigger1
execute as @a if data entity @s LastDeathLocation if score @s bizcub.death_coords.trigger1 matches 1.. run tellraw @s [{"nbt":"LastDeathLocation.pos[0]","entity":"@s"},", ",{"nbt":"LastDeathLocation.pos[1]","entity":"@s"},", ",{"nbt":"LastDeathLocation.pos[2]","entity":"@s"}]
execute as @a unless data entity @s LastDeathLocation if score @s bizcub.death_coords.trigger1 matches 1.. run tellraw @s {"translate":"arguments.nbtpath.nothing_found","with":["Last Death Location"],"color":"red"}
scoreboard players set @a bizcub.death_coords.trigger1 0
